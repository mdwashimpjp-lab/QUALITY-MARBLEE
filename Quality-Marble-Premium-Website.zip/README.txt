QUALITY MARBLE — PREMIUM WEBSITE
Open index.html in any modern browser.

Includes:
- Luxury responsive design
- Hero section with real showroom photo
- Product/collection sections
- Photo gallery
- Customer reviews
- Call + WhatsApp CTAs
- Google Maps direction link
- Mobile-friendly layout
- No external JavaScript required

Before going live:
1. Add the official logo if available.
2. Confirm phone, address and opening hours.
3. Connect a custom domain/hosting.
4. Add product names/prices if you want an online catalogue.
